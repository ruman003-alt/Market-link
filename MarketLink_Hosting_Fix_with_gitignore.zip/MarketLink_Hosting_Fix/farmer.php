<?php
$page_title = 'Farmer Store';

// Load the same database/session connection used by the rest of MarketLink.
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

$farmer_id = (int)($_GET['id'] ?? 0);
if ($farmer_id <= 0) {
    header('Location: products.php');
    exit;
}

$fq = mysqli_query($conn, "SELECT id,name,email,phone,address,status,created_at FROM users WHERE id=$farmer_id AND role='farmer' AND status='active' LIMIT 1");
if (!$fq || mysqli_num_rows($fq) === 0) {
    header('Location: products.php');
    exit;
}
$farmer = mysqli_fetch_assoc($fq);
$products = mysqli_query($conn, "SELECT * FROM products WHERE farmer_id=$farmer_id AND status='available' ORDER BY id DESC");
$product_count = $products ? mysqli_num_rows($products) : 0;
include 'header.php';
?>

<div class="farmer-store-hero">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
                <span class="eyebrow">Local Farmer Store</span>
                <h1 class="farmer-store-title"><?= e($farmer['name']) ?></h1>
                <p class="farmer-store-subtitle mb-0">View this farmer's profile, contact details and available products.</p>
            </div>
            <a href="products.php" class="btn btn-burgundy"><i class="fa-solid fa-arrow-left me-1"></i>Back to Products</a>
        </div>
    </div>
</div>

<div class="container py-5">
    <div class="row g-4 align-items-stretch">
        <div class="col-lg-4">
            <div class="farmer-profile-card h-100">
                <div class="farmer-profile-avatar"><i class="fa-solid fa-tractor"></i></div>
                <span class="badge badge-burgundy mb-2">Approved Farmer</span>
                <h3><?= e($farmer['name']) ?></h3>
                <div class="farmer-profile-info">
                    <?php if (!empty($farmer['phone'])): ?>
                        <div><i class="fa-solid fa-phone"></i><span><?= e($farmer['phone']) ?></span></div>
                    <?php endif; ?>
                    <?php if (!empty($farmer['email'])): ?>
                        <div><i class="fa-solid fa-envelope"></i><span><?= e($farmer['email']) ?></span></div>
                    <?php endif; ?>
                    <?php if (!empty($farmer['address'])): ?>
                        <div><i class="fa-solid fa-location-dot"></i><span><?= nl2br(e($farmer['address'])) ?></span></div>
                    <?php endif; ?>
                </div>
                <div class="farmer-profile-stat">
                    <strong><?= $product_count ?></strong>
                    <span>Available Products</span>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="dashboard-card h-100">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                    <div>
                        <span class="eyebrow">Farmer Store</span>
                        <h3 class="mb-0">Products by <?= e($farmer['name']) ?></h3>
                    </div>
                    <span class="listing-count"><?= $product_count ?> Products</span>
                </div>

                <?php if ($product_count === 0): ?>
                    <div class="farmer-empty-store">
                        <i class="fa-solid fa-box-open"></i>
                        <h5>No products available</h5>
                        <p class="text-secondary mb-0">This farmer has not listed any available products yet.</p>
                    </div>
                <?php else: ?>
                    <div class="row g-3">
                        <?php while ($p = mysqli_fetch_assoc($products)): ?>
                            <div class="col-md-6">
                                <div class="farmer-store-product">
                                    <div class="farmer-store-product-image">
                                        <?php if (!empty($p['image'])): ?>
                                            <img src="uploads/products/<?= e($p['image']) ?>" alt="<?= e($p['name']) ?>"
                                                 onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
                                            <div class="black-product-placeholder" style="display:none;">Your product image</div>
                                        <?php else: ?>
                                            <div class="black-product-placeholder">Your product image</div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="p-3">
                                        <span class="badge badge-burgundy mb-2"><?= e($p['category']) ?></span>
                                        <h5 class="mb-1"><?= e($p['name']) ?></h5>
                                        <p class="small text-secondary mb-2 product-short-description"><?= e($p['short_description']) ?></p>
                                        <div class="d-flex justify-content-between align-items-center gap-2">
                                            <strong class="text-burgundy">Rs. <?= number_format($p['price'], 2) ?> <small>/ <?= e($p['unit']) ?></small></strong>
                                            <a class="btn btn-burgundy btn-sm" href="product.php?id=<?= (int)$p['id'] ?>">View More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
