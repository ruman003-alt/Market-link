</main>
<footer class="footer">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-5"><h4>MarketLink</h4><p class="mb-2">Connecting local farmers with their community through clearer stock information, pre-orders and convenient pickup markets.</p><small>Fresh products • Local markets • Community shopping</small></div>
      <div class="col-md-3 col-lg-2"><h6>Explore</h6><div class="footer-links d-block"><a class="d-block mb-2" href="products.php">Products</a><a class="d-block mb-2" href="markets.php">Markets</a><a class="d-block mb-2" href="register.php">Register</a></div></div>
      <div class="col-md-4 col-lg-3"><h6>For Farmers</h6><p class="small mb-2">Create your farmer account, get approved by admin and manage your own weekly inventory.</p><a href="register.php" class="btn btn-footer-marketlink btn-sm"><i class="fa-solid fa-cart-shopping me-1"></i>Join MarketLink as a Farmer</a></div>
      <div class="col-md-5 col-lg-2"><h6>Need help?</h6><p class="small mb-0">Use your MarketLink account to track orders, save products and manage marketplace activity.</p></div>
    </div>
    <hr class="border-light opacity-25 my-4"><div class="d-flex justify-content-between flex-wrap gap-2"><small>© <?=date('Y')?> MarketLink</small><small>Pickup orders are paid in person at the market.</small></div>
  </div>
</footer>
<script src="assets/animations.js"></script><script src="assets/session-protection.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script><link rel="stylesheet" href="assets/ai-chatbot.css"><script src="assets/ai-chatbot.js" data-api="api/openrouter.php"></script></body></html>
