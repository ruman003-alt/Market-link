<?php
$page_title = 'Products';
include 'header.php';

$where = "p.status='available'";

if (!empty($_GET['q'])) {
    $q = mysqli_real_escape_string($conn, $_GET['q']);
    $where = $where . " AND (p.name LIKE '%$q%' OR p.category LIKE '%$q%')";
}

if (!empty($_GET['category'])) {
    $category = mysqli_real_escape_string($conn, $_GET['category']);
    $where = $where . " AND p.category='$category'";
}

$query = "SELECT p.*, u.name AS farmer_name
          FROM products p
          JOIN users u ON p.farmer_id = u.id
          WHERE $where
          ORDER BY p.id DESC";

$products = mysqli_query($conn, $query);
$cats = mysqli_query($conn, "SELECT DISTINCT category FROM products ORDER BY category");
?>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <span class="eyebrow">Fresh • Local • Trusted</span>
            <h2 class="section-title mb-1">Our Products</h2>
            <p class="small-muted mb-0">Browse products from approved local farmers.</p>
        </div>

        <form class="d-flex gap-2 flex-wrap">
            <input class="form-control" name="q" placeholder="Search product" value="<?= e($_GET['q'] ?? '') ?>">
            <select class="form-select" name="category">
                <option value="">All categories</option>
                <?php while ($c = mysqli_fetch_assoc($cats)): ?>
                    <option value="<?= e($c['category']) ?>" <?= ($_GET['category'] ?? '') === $c['category'] ? 'selected' : '' ?>>
                        <?= e($c['category']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
            <button class="btn btn-burgundy" type="submit">Search</button>
        </form>
    </div>

    <div class="row g-4 mt-2">
        <?php if (mysqli_num_rows($products) == 0): ?>
            <div class="col-12">
                <div class="card p-5 text-center">
                    <h4 class="text-burgundy">No products are available yet</h4>
                    <p class="text-secondary mb-0">Approved farmers can add products from their Farmer Dashboard.</p>
                </div>
            </div>
        <?php endif; ?>

        <?php while ($p = mysqli_fetch_assoc($products)): ?>
            <div class="col-sm-6 col-lg-4">
                <div class="card product-catalog-card h-100 overflow-hidden d-flex flex-column">
                    <div class="product-image-wrap">
                        <?php if (!empty($p['image'])): ?>
                            <img src="uploads/products/<?= e($p['image']) ?>"
                                 class="product-img"
                                 alt="<?= e($p['name']) ?>"
                                 onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                            <div class="product-img black-product-placeholder" style="display:none;">Your product image</div>
                        <?php else: ?>
                            <div class="product-img black-product-placeholder">Your product image</div>
                        <?php endif; ?>
                    </div>

                    <div class="p-4 d-flex flex-column flex-grow-1">
                        <div class="d-flex justify-content-between align-items-center gap-2 mb-2">
                            <span class="badge badge-burgundy"><?= e($p['category']) ?></span>
                            <span class="stock-badge">
                                <i class="fa-solid fa-circle-check me-1"></i>
                                In Stock: <?= e($p['stock_quantity']) ?>
                            </span>
                        </div>

                        <h5 class="product-card-title"><?= e($p['name']) ?></h5>
                        <p class="product-farmer mb-2"><i class="fa-solid fa-user me-1"></i><?= e($p['farmer_name']) ?></p>
                        <p class="text-secondary product-short-description" title="<?= e($p['short_description']) ?>"><?= e($p['short_description']) ?></p>

                        <strong class="product-card-price">
                            Rs. <?= number_format($p['price'], 2) ?>
                            <small>/ <?= e($p['unit']) ?></small>
                        </strong>

                        <div class="product-card-actions">
                            <a class="btn btn-burgundy view-product-btn" href="product.php?id=<?= (int)$p['id'] ?>">
                                <i class="fa-solid fa-arrow-right me-1"></i>View More
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<?php include 'footer.php'; ?>
