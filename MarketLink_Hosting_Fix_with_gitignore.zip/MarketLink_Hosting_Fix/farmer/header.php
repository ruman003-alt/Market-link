<?php require_once __DIR__.'/../config.php'; require_once __DIR__.'/../functions.php'; require_role('farmer'); $me=mysqli_query($conn,"SELECT status FROM users WHERE id=".(int)$_SESSION['user_id']); $ms=mysqli_fetch_assoc($me); if(!$ms || $ms['status']!=='active'){session_unset();session_destroy();header('Location: ../login.php');exit;} $dashboard_page = basename($_SERVER['PHP_SELF']); ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Farmer | MarketLink</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"><link rel="stylesheet" href="../assets/style.css"></head><body class="dashboard-body">
<div class="admin-shell">
  <aside class="dashboard-sidebar" id="farmerSidebar">
    <div class="sidebar-brand"><img src="../assets/marketlink-brand.png" alt="MarketLink"></div>
    <div class="farmer-mini"><div class="profile-avatar large">F</div><div><strong><?=e($_SESSION['name'])?></strong><small>Approved Farmer</small></div></div>
    <div class="sidebar-label">FARMER MENU</div>
    <a href="index.php" class="sidebar-link <?= $dashboard_page==='index.php'?'active':'' ?>"><i class="fa-solid fa-chart-line"></i><span>Dashboard</span></a>
    <a class="sidebar-link sidebar-product-cta <?= $dashboard_page==='products.php'?'active':'' ?>" href="products.php"><i class="fa-solid fa-circle-plus"></i><span>Add / Manage Products</span></a>
    <a href="orders.php" class="sidebar-link <?= $dashboard_page==='orders.php'?'active':'' ?>"><i class="fa-solid fa-receipt"></i><span>Customer Orders</span></a>
    <a class="sidebar-link" href="../farmer.php?id=<?= (int)$_SESSION['user_id'] ?>"><i class="fa-solid fa-store"></i><span>View Store</span></a>
    <div class="sidebar-spacer"></div>
    <a class="sidebar-link sidebar-link-soft" href="../index.php"><i class="fa-solid fa-house"></i><span>Home Page</span></a>
    <a class="sidebar-link sidebar-link-danger" href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i><span>Logout</span></a>
  </aside>
  <div class="dashboard-main">
    <header class="dashboard-topbar"><button class="sidebar-toggle" onclick="document.getElementById('farmerSidebar').classList.toggle('show')"><i class="fa-solid fa-bars"></i></button><div><span class="topbar-kicker">MARKETLINK FARMER</span><h1 class="topbar-title">Farmer Workspace</h1></div><div class="topbar-profile"><div class="profile-avatar">F</div><div><strong><?=e($_SESSION['name'])?></strong><small>Manage your marketplace</small></div></div></header>
    <main class="dashboard-content">
