<?php require_once __DIR__.'/../config.php'; require_once __DIR__.'/../functions.php'; require_role('admin'); $dashboard_page = basename($_SERVER['PHP_SELF']); ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin | MarketLink</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"><link rel="stylesheet" href="../assets/style.css"></head><body class="dashboard-body">
<div class="admin-shell">
  <aside class="dashboard-sidebar" id="adminSidebar">
    <div class="sidebar-brand"><img src="../assets/marketlink-brand.png" alt="MarketLink"></div>
    <div class="sidebar-label">MAIN MENU</div>
    <a href="index.php" class="sidebar-link <?= $dashboard_page==='index.php'?'active':'' ?>"><i class="fa-solid fa-chart-pie"></i><span>Dashboard</span></a>
    <a href="farmers.php" class="sidebar-link <?= $dashboard_page==='farmers.php'?'active':'' ?>"><i class="fa-solid fa-tractor"></i><span>Farmers</span></a>
    <a href="users.php" class="sidebar-link <?= $dashboard_page==='users.php'?'active':'' ?>"><i class="fa-solid fa-users"></i><span>Customers & Users</span></a>
    <a href="products.php" class="sidebar-link <?= $dashboard_page==='products.php'?'active':'' ?>"><i class="fa-solid fa-box-open"></i><span>Products</span><span class="sidebar-add">Manage</span></a>
    <a href="markets.php" class="sidebar-link <?= $dashboard_page==='markets.php'?'active':'' ?>"><i class="fa-solid fa-store"></i><span>Markets</span></a>
    <a href="reviews.php" class="sidebar-link <?= $dashboard_page==='reviews.php'?'active':'' ?>"><i class="fa-solid fa-star"></i><span>Reviews</span></a>
    <a href="reports.php" class="sidebar-link <?= $dashboard_page==='reports.php'?'active':'' ?>"><i class="fa-solid fa-chart-column"></i><span>Reports</span></a>
    <div class="sidebar-spacer"></div>
    <a class="sidebar-link sidebar-link-soft" href="../index.php"><i class="fa-solid fa-globe"></i><span>View Website</span></a>
    <a class="sidebar-link sidebar-link-danger" href="../logout.php"><i class="fa-solid fa-right-from-bracket"></i><span>Logout</span></a>
  </aside>
  <div class="dashboard-main">
    <header class="dashboard-topbar"><button class="sidebar-toggle" onclick="document.getElementById('adminSidebar').classList.toggle('show')"><i class="fa-solid fa-bars"></i></button><div><span class="topbar-kicker">MARKETLINK ADMIN</span><h1 class="topbar-title">Platform Control Center</h1></div><div class="topbar-profile"><div class="profile-avatar">A</div><div><strong><?=e($_SESSION['name'])?></strong><small>Administrator</small></div></div></header>
    <main class="dashboard-content">
