<?php
$page_title='Register';
include 'header.php';
$error='';
$success='';
$product_id=(int)($_GET['product_id'] ?? 0);

if($product_id > 0){
    $_SESSION['login_redirect']='product';
    $_SESSION['login_product_id']=$product_id;
}

if($_SERVER['REQUEST_METHOD']==='POST'){ $name=mysqli_real_escape_string($conn,$_POST['name']);$email=mysqli_real_escape_string($conn,$_POST['email']);$phone=mysqli_real_escape_string($conn,$_POST['phone']);$address=mysqli_real_escape_string($conn,$_POST['address']);$password=password_hash($_POST['password'],PASSWORD_DEFAULT);$role=$_POST['role']==='farmer'?'farmer':'customer';$q=mysqli_query($conn,"SELECT id FROM users WHERE email='$email'");if(mysqli_num_rows($q)>0){$error='Email already exists.';}else{mysqli_query($conn,"INSERT INTO users(name,email,password,role,phone,address,status) VALUES('$name','$email','$password','$role','$phone','$address',".($role==='farmer'?"'pending'":"'active'").")");

        // Send a registration email to the email address entered by the user.
        $subject = 'Welcome to MarketLink';
        if ($role === 'farmer') {
            $subject = 'MarketLink Farmer Registration Received';
            $message = "Hello $name,

Thank you for registering as a farmer on MarketLink.

Your farmer registration has been received successfully. Your account is currently pending admin approval.

We will use this email address for MarketLink account communication.

Regards,
MarketLink Team";
        } else {
            $message = "Hello $name,

Welcome to MarketLink!

Your customer account has been created successfully.

You can now log in and explore products, markets and place orders.

Regards,
MarketLink Team";
        }

        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        $headers .= "From: MarketLink <noreply@marketlink.com>\r\n";
        $headers .= "Reply-To: noreply@marketlink.com\r\n";

        @mail($email, $subject, $message, $headers);

        if($role==='customer'){
    $newid=mysqli_insert_id($conn);
    session_regenerate_id(true);
    $_SESSION['user_id']=$newid;
    $_SESSION['name']=$name;
    $_SESSION['role']='customer';

    if(!empty($_SESSION['pending_cart_product_id'])){
        $pid=(int)$_SESSION['pending_cart_product_id'];
        $pending_qty=(int)($_SESSION['pending_cart_quantity'] ?? 1);
        $product_check=mysqli_query($conn,"SELECT stock_quantity FROM products WHERE id=$pid AND status='available' LIMIT 1");

        if(mysqli_num_rows($product_check)>0){
            $product_row=mysqli_fetch_assoc($product_check);
            if($pending_qty > (int)$product_row['stock_quantity']){
                $pending_qty=(int)$product_row['stock_quantity'];
            }
            if($pending_qty > 0){
                $_SESSION['cart']=[$pid=>$pending_qty];
            }
        }

        unset($_SESSION['pending_cart_product_id'],$_SESSION['pending_cart_quantity']);

        if(!empty($_SESSION['login_product_id'])){
            $pid=(int)$_SESSION['login_product_id'];
            unset($_SESSION['login_redirect'],$_SESSION['login_product_id']);
            header('Location: product.php?id='.$pid.'&added=1');
            exit;
        }
    }

    header('Location: products.php');
    exit;
} $success='Farmer registration submitted. Admin approval is required before product listing.';}} ?>

<div class="auth-wrap auth-page">
  <div class="container">
    <div class="auth-layout auth-register-layout">
      <div class="auth-info">
        <img src="assets/marketlink-brand.png" alt="MarketLink" class="auth-logo">
        <span class="auth-kicker">JOIN MARKETLINK</span>
        <h1>Be part of your<br>local marketplace.</h1>
        <p>Create your free account and discover a simple way to connect with local farmers, fresh products and nearby pickup markets.</p>
        <div class="auth-points">
          <div><i class="fa-solid fa-user-check"></i><span>Quick and simple registration</span></div>
          <div><i class="fa-solid fa-leaf"></i><span>Discover local farm products</span></div>
          <div><i class="fa-solid fa-store"></i><span>Join as a customer or farmer</span></div>
        </div>
      </div>

      <div class="auth-card card p-4 p-md-5">
        <div class="auth-form-head">
          <span class="auth-form-icon"><i class="fa-solid fa-user-plus"></i></span>
          <div>
            <h3>Create Account</h3>
            <p>Register to get started with MarketLink.</p>
          </div>
        </div>

        <?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?>
        <?php if($success):?><div class="alert alert-success"><?=e($success)?></div><?php endif;?>
        <?php if($product_id > 0): ?><div class="login-cart-box mb-4"><i class="fa-solid fa-user-plus"></i><div><strong>Create an account to add this product</strong><span>Your product will be added to your cart after registration.</span></div></div><?php endif;?>

        <form method="post">
          <label class="auth-label">Full Name / Stall Name</label>
          <div class="auth-input-wrap"><i class="fa-regular fa-user"></i><input class="form-control" name="name" placeholder="Enter your name or stall name" required></div>

          <label class="auth-label">Email Address</label>
          <div class="auth-input-wrap"><i class="fa-regular fa-envelope"></i><input class="form-control" type="email" name="email" placeholder="Enter your email" required></div>

          <div class="row g-2">
            <div class="col-md-6">
              <label class="auth-label">Contact Number</label>
              <div class="auth-input-wrap"><i class="fa-solid fa-phone"></i><input class="form-control" name="phone" placeholder="Contact number" required></div>
            </div>
            <div class="col-md-6">
              <label class="auth-label">Account Type</label>
              <select class="form-select auth-select" name="role">
                <option value="customer">Customer</option>
                <option value="farmer">Farmer</option>
              </select>
            </div>
          </div>

          <label class="auth-label">Address</label>
          <div class="auth-input-wrap auth-textarea-wrap"><i class="fa-solid fa-location-dot"></i><textarea class="form-control" name="address" placeholder="Enter your address" required></textarea></div>

          <label class="auth-label">Password</label>
          <div class="auth-input-wrap"><i class="fa-solid fa-lock"></i><input class="form-control" type="password" name="password" placeholder="Create a password" required></div>

          <button class="btn btn-burgundy w-100 auth-submit"><i class="fa-solid fa-user-plus me-2"></i>Create Account</button>
        </form>

        <p class="auth-switch">Already have an account? <a href="login.php">Login here</a></p>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>