<?php
$page_title='MarketLink | Local Farmers Marketplace';
include 'header.php';
?>
<section class="hero hero-home">
  <div class="hero-decor" aria-hidden="true">
    <span class="hero-orb hero-orb-1"></span>
    <span class="hero-orb hero-orb-2"></span>
    <span class="hero-ring hero-ring-1"></span>
    <span class="hero-ring hero-ring-2"></span>
  </div>
  <div class="container position-relative">
    <div class="row align-items-center g-4 g-xl-5">
      <div class="col-lg-6">
        <div class="hero-copy-wrap">
          <span class="badge badge-burgundy mb-3">Fresh • Local • Pickup</span>
          <h1 class="display-4 fw-bold">A cleaner way to discover products from local farmers.</h1>
          <p class="lead text-secondary">MarketLink connects customers with approved local farmers through live products, clear pricing, useful product information, pickup planning and simple pre-orders.</p>
          <div class="d-flex flex-wrap gap-2 mb-4">
            <a href="products.php" class="btn btn-burgundy btn-lg">Browse Products</a>
            <a href="markets.php" class="btn btn-outline-dark btn-lg">Find Markets</a>
            <a href="register.php" class="btn btn-light border btn-lg">Create Account</a>
          </div>
          <div class="hero-points"><span>✓ Live farmer listings</span><span>✓ Pickup focused</span><span>✓ Pay at pickup</span></div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="hero-photo-stage">
          <div class="hero-image-card hero-image-card-large">
            <div class="hero-photo-shine"></div>
            <img src="assets/home/hero-real-market.jpg" class="img-fluid real-photo" alt="Customers shopping in a real fresh produce store">
            <div class="hero-floating-card">
              <strong>Real market experience</strong><br>
              <span>Browse products, compare stock and plan your pickup before you visit.</span>
            </div>
          </div>
          <div class="hero-float-badge hero-float-one"><i class="fa-solid fa-basket-shopping"></i><div><strong>Fresh picks</strong><small>Updated listings</small></div></div>
          <div class="hero-float-badge hero-float-two"><i class="fa-solid fa-location-dot"></i><div><strong>Easy pickup</strong><small>Find nearby markets</small></div></div>
          <div class="hero-float-dot hero-dot-one"></div>
          <div class="hero-float-dot hero-dot-two"></div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="py-4 border-bottom bg-white">
  <div class="container"><div class="row g-3">
    <div class="col-md-3"><div class="mini-feature"><span>01</span><div><strong>Discover</strong><small>Search farmers, markets and products.</small></div></div></div>
    <div class="col-md-3"><div class="mini-feature"><span>02</span><div><strong>Review</strong><small>See price, unit, stock and descriptions.</small></div></div></div>
    <div class="col-md-3"><div class="mini-feature"><span>03</span><div><strong>Reserve</strong><small>Add products and prepare a pickup order.</small></div></div></div>
    <div class="col-md-3"><div class="mini-feature"><span>04</span><div><strong>Collect</strong><small>Pick up and pay directly at the market.</small></div></div></div>
  </div></div>
</section>

<section class="py-5">
  <div class="container">
    <div class="section-heading d-flex justify-content-between align-items-end flex-wrap gap-3">
      <div><span class="eyebrow">Live marketplace</span><h2 class="section-title mb-1">Latest products</h2><p class="small-muted mb-0">This section is connected to the database. Whenever an approved farmer adds a product, it can appear here automatically.</p></div>
      <a href="products.php" class="text-burgundy fw-bold">View all products →</a>
    </div>
    <div class="row g-4 mt-1">
      <?php
      $latest=mysqli_query($conn,"SELECT p.*,u.name farmer_name FROM products p JOIN users u ON p.farmer_id=u.id WHERE p.status='available' ORDER BY p.id DESC LIMIT 9");
      if(mysqli_num_rows($latest)===0):
      ?>
        <div class="col-12"><div class="empty-state-home text-center py-5"><i class="fa-solid fa-basket-shopping empty-icon"></i><h4>No products available yet</h4><p class="text-secondary mb-0">Approved farmers can add products from the Farmer Panel. New products will appear here automatically.</p></div></div>
      <?php else: while($p=mysqli_fetch_assoc($latest)): $img=$p['image']; $src=$img?'uploads/products/'.$img:'assets/default-product.svg'; ?>
        <div class="col-sm-6 col-lg-4">
          <div class="card product-catalog-card home-product-card h-100 overflow-hidden d-flex flex-column"
               role="link" tabindex="0"
               onclick="window.location.href='product.php?id=<?=(int)$p['id']?>'"
               onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();window.location.href='product.php?id=<?=(int)$p['id']?>'}">
            <img src="<?=e($src)?>" class="product-img" alt="<?=e($p['name'])?>" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
            <div class="product-img black-product-placeholder" style="display:none;">Your product image</div>
            <div class="p-4 d-flex flex-column flex-grow-1">
              <span class="badge badge-burgundy mb-2 align-self-start"><?=e($p['category'])?></span>
              <h5><?=e($p['name'])?></h5>
              <p class="text-secondary product-short-description home-product-short-description" title="<?=e($p['short_description'])?>"><?=e($p['short_description'])?></p>
              <strong>Rs. <?=number_format($p['price'],2)?> / <?=e($p['unit'])?></strong>
              <div class="product-card-actions">
                <a href="product.php?id=<?=(int)$p['id']?>" class="btn btn-burgundy view-product-btn"><i class="fa-solid fa-eye me-1"></i>View Product</a>
              </div>
            </div>
          </div>
        </div>
      <?php endwhile; endif; ?>
    </div>
    <div class="text-center mt-4">
      <a href="products.php" class="btn btn-outline-burgundy btn-lg px-4"><i class="fa-solid fa-grid-2 me-2"></i>View More Products</a>
    </div>
  </div>
</section>

<section class="py-5 soft-section"><div class="container"><div class="row g-5 align-items-center"><div class="col-lg-6"><img src="https://images.pexels.com/photos/17302468/pexels-photo-17302468.jpeg?cs=srgb&dl=pexels-kelly-17302468.jpg&fm=jpg" class="img-fluid rounded-4" alt="Market illustration"></div><div class="col-lg-6"><span class="eyebrow">Why MarketLink?</span><h2 class="section-title">Everything useful in one marketplace.</h2><p class="text-secondary">Customers can browse live inventory while farmers control their own product names, descriptions, prices, stock and images. Admin users keep the marketplace organised through role-based management.</p><div class="benefit-list"><div><strong>Farmer-controlled products</strong><span>Add, edit and delete your own listings without preloaded demo inventory.</span></div><div><strong>Real customer information</strong><span>Orders contain customer name, phone, address, customer details and total bill.</span></div><div><strong>Image-first product pages</strong><span>Your uploaded gallery images are shown directly on the product detail page.</span></div><div><strong>Simple local ordering</strong><span>No online payment gateway is required; payment happens at pickup.</span></div></div></div></div></div></section>

<section class="py-5"><div class="container"><div class="section-heading"><span class="eyebrow">New articles</span><h2 class="section-title">Fresh ideas for local shoppers</h2><p class="small-muted">Useful marketplace content for planning market visits, choosing seasonal products and improving farmer listings.</p></div><div class="row g-4"><div class="col-lg-4"><a href="article.php?slug=shopping-seasonal" class="article-card"><img src="https://images.pexels.com/photos/13624600/pexels-photo-13624600.jpeg?cs=srgb&dl=pexels-muhammad-jamshed-azam-271959100-13624600.jpg&fm=jpg" alt="Seasonal shopping"><div class="p-4"><span class="article-tag">SHOPPING GUIDE</span><h4>How to shop smarter with seasonal produce</h4><p>Understand availability, compare listings and plan purchases around weekly market schedules.</p><span class="read-more">Read article →</span></div></a></div><div class="col-lg-4"><a href="article.php?slug=market-day" class="article-card"><img src="https://images.pexels.com/photos/1363850/pexels-photo-1363850.jpeg?cs=srgb&dl=pexels-shanekell-1363850.jpg&fm=jpg" alt="Market day"><div class="p-4"><span class="article-tag">MARKET DAY</span><h4>What to check before visiting a market</h4><p>Use a simple checklist for timings, stock, market schedules and order planning.</p><span class="read-more">Read article →</span></div></a></div><div class="col-lg-4"><a href="article.php?slug=farmers" class="article-card"><img src="https://images.pexels.com/photos/1751226/pexels-photo-1751226.jpeg?cs=srgb&dl=pexels-aadil-1751226.jpg&fm=jpg" alt="Farmer listing"><div class="p-4"><span class="article-tag">FOR FARMERS</span><h4>How to build a useful weekly listing</h4><p>Write clearer descriptions, upload strong product photos and keep stock accurate.</p><span class="read-more">Read article →</span></div></a></div></div></div></section>

<section class="py-5"><div class="container"><div class="row g-4"><div class="col-lg-4"><div class="info-card h-100"><i class="fa-solid fa-store feature-icon"></i><h5>Local markets</h5><p>Browse market names, addresses, operating days and pickup information before planning a visit.</p></div></div><div class="col-lg-4"><div class="info-card h-100"><i class="fa-solid fa-basket-shopping feature-icon"></i><h5>Simple pre-orders</h5><p>Select products, enter your contact information, choose a pickup slot and receive a complete bill.</p></div></div><div class="col-lg-4"><div class="info-card h-100"><i class="fa-solid fa-shield-halved feature-icon"></i><h5>Role-based access</h5><p>Admins, farmers and customers see only the controls and workflows related to their roles.</p></div></div></div></div></section>

<section class="py-5 dark-cta"><div class="container"><div class="row align-items-center g-4"><div class="col-lg-8"><span class="eyebrow light">For local farmers</span><h2>Have products to list this week?</h2><p>Register as a farmer, wait for admin approval and then manage your own products, gallery images, stock, orders and customer information from the premium Farmer Panel.</p></div><div class="col-lg-4 text-lg-end"><a href="register.php" class="btn btn-light btn-lg">Register as Farmer</a></div></div></div></section>
<?php include 'footer.php'; ?>
