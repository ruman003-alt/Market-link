<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../functions.php';
require_role('customer');

$cart_count = 0;

if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $quantity) {
        $cart_count = $cart_count + (int)$quantity;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>MarketLink</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg main-navbar">
    <div class="container nav-container">
        <a class="navbar-brand brand nav-brand" href="../index.php">
            <img src="../assets/marketlink-brand.png" alt="MarketLink" class="nav-logo">
        </a>

        <button class="navbar-toggler nav-toggle" type="button" data-bs-toggle="collapse" data-bs-target="#customerNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="customerNav">
            <div class="ms-auto d-flex flex-column flex-lg-row align-items-lg-center gap-2 customer-nav-actions">
                <a class="nav-link" href="../products.php">
                    <i class="fa-solid fa-basket-shopping"></i> Products
                </a>

                <a class="nav-link" href="orders.php">
                    <i class="fa-solid fa-receipt"></i> My Orders
                </a>

                <a class="nav-link nav-cart-link" href="cart.php">
                    <i class="fa-solid fa-cart-shopping"></i> Cart
                    <?php if ($cart_count > 0): ?>
                        <span class="cart-count"><?= $cart_count ?></span>
                    <?php endif; ?>
                </a>

                <a class="btn btn-nav-logout nav-action-btn" href="../logout.php">
                    <i class="fa-solid fa-right-from-bracket"></i> Logout
                </a>
            </div>
        </div>
    </div>
</nav>
<main>
