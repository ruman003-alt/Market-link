<?php include 'header.php'; $cart=$_SESSION['cart']??[]; $total=0; $customer=mysqli_fetch_assoc(mysqli_query($conn,"SELECT id FROM users WHERE id=".(int)$_SESSION['user_id'])); $contact_ready=false; ?><div class="container py-5"><?php if(!empty($_SESSION['order_error'])): ?><div class="alert alert-warning border-0 shadow-sm"><?=e($_SESSION['order_error'])?></div><?php unset($_SESSION['order_error']); endif; ?>
<div class="d-flex justify-content-between align-items-end flex-wrap gap-3 mb-4"><div><span class="eyebrow">Checkout</span><h2 class="section-title mb-1">Your Pre-Order</h2><p class="small-muted mb-0">Confirm your customer contact information before placing the order.</p></div><a href="../products.php" class="btn btn-outline-dark">Continue Shopping</a></div><?php if(!$cart): ?><div class="dashboard-card text-center py-5"><i class="fa-solid fa-cart-shopping empty-icon"></i><h4>Your cart is empty</h4><p class="text-secondary">Add products from the marketplace to prepare your order.</p><a href="../products.php" class="btn btn-burgundy">Browse Products</a></div><?php else: ?><div class="row g-4"><div class="col-lg-8"><div class="dashboard-card"><h4 class="mb-3">Order Items</h4><div class="table-responsive"><table class="table align-middle"><thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Total</th><th></th></tr></thead><tbody><?php foreach($cart as $id=>$qty): $id=(int)$id; $q=mysqli_query($conn,"SELECT * FROM products WHERE id=$id AND status='available'"); if(mysqli_num_rows($q)==0)continue; $p=mysqli_fetch_assoc($q); $line=$p['price']*$qty; $total+=$line; ?><tr><td><strong><?=e($p['name'])?></strong><div class="small-muted"><?=e($p['unit'])?></div></td><td>Rs. <?=number_format($p['price'],2)?></td><td><?=e($qty)?></td><td><strong>Rs. <?=number_format($line,2)?></strong></td><td><a class="btn btn-sm btn-outline-danger" href="remove_cart.php?id=<?=$id?>">Remove</a></td></tr><?php endforeach; ?></tbody></table></div></div></div><div class="col-lg-4"><div class="checkout-sticky dashboard-card"><h4>Customer Contact</h4><div class="order-contact-check <?= $contact_ready ? 'ready' : 'missing' ?>"><?php if($contact_ready): ?><i class="fa-solid fa-circle-check"></i><span>Your name, phone number and address are available. You can confirm your order.</span><?php else: ?><i class="fa-solid fa-triangle-exclamation"></i><span>Please complete your name, phone number and address before placing an order.</span><?php endif; ?></div><form method="post" action="place_order.php" onsubmit="return checkOrderContact();"><label class="form-label">Full Name</label><input class="form-control mb-3" name="customer_name" value="" placeholder="Enter your full name" pattern="[A-Za-z .'-]{2,60}" title="Please enter a valid name" autocomplete="name" required><label class="form-label">Phone Number</label><input class="form-control mb-3" name="customer_phone" value="" placeholder="03XXXXXXXXX" pattern="03[0-9]{9}" maxlength="11" inputmode="numeric" title="Enter an 11-digit Pakistani mobile number starting with 03" autocomplete="tel" required><label class="form-label">Delivery / Pickup Address</label><textarea class="form-control mb-3" name="customer_address" rows="3" placeholder="Enter your complete delivery / pickup address" autocomplete="street-address" required></textarea><div class="order-total-box mb-3"><span>Total Bill</span><strong>Rs. <?=number_format($total,2)?></strong></div><button class="btn btn-burgundy w-100 btn-lg" type="submit"><i class="fa-solid fa-check me-1"></i>Confirm Order</button><p class="small-muted mt-2 mb-0">Payment is made in person at pickup.</p></form></div></div></div><?php endif; ?>
<script>
function checkOrderContact(){
    var name=document.querySelector('[name="customer_name"]').value;
    var phone=document.querySelector('[name="customer_phone"]').value;
    var address=document.querySelector('[name="customer_address"]').value;
    var nameRegex=/^[A-Za-z .'-]{2,60}$/;
    var phoneRegex=/^03[0-9]{9}$/;
    if(name==='' || phone==='' || address===''){
        alert('Please enter your name, phone number and address.');
        return false;
    }
    if(!nameRegex.test(name)){
        alert('Please enter a valid name.');
        return false;
    }
    if(!phoneRegex.test(phone)){
        alert('Please enter a valid 11-digit Pakistani mobile number starting with 03.');
        return false;
    }
    if(address.length < 5){
        alert('Please enter a complete delivery / pickup address.');
        return false;
    }
    return true;
}
</script>
</div><?php include 'footer.php'; ?>
