<?php
require '../config.php';
require '../functions.php';

$id = (int)($_POST['product_id'] ?? 0);
$qty = (int)($_POST['quantity'] ?? 1);

if ($id <= 0) {
    header('Location: ../products.php');
    exit;
}

$query = "SELECT * FROM products WHERE id=$id AND status='available'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 0) {
    header('Location: ../products.php');
    exit;
}

$product = mysqli_fetch_assoc($result);

if ($qty < 1) {
    $qty = 1;
}

if ($qty > (int)$product['stock_quantity']) {
    $qty = (int)$product['stock_quantity'];
}

/* A product detail page is public. Login is required only when adding to cart. */
if (!isset($_SESSION['user_id'])) {
    $_SESSION['pending_cart_product_id'] = $id;
    $_SESSION['pending_cart_quantity'] = $qty;
    $_SESSION['login_redirect'] = 'product';
    $_SESSION['login_product_id'] = $id;
    header('Location: ../login.php?product_id=' . $id);
    exit;
}

if (($_SESSION['role'] ?? '') !== 'customer') {
    header('Location: ../product.php?id=' . $id . '&cart_error=customer');
    exit;
}

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (isset($_SESSION['cart'][$id])) {
    $_SESSION['cart'][$id] = $_SESSION['cart'][$id] + $qty;
} else {
    $_SESSION['cart'][$id] = $qty;
}

header('Location: ../product.php?id=' . $id . '&added=1');
exit;
?>
