<?php require '../config.php';require '../functions.php';require_role('customer');$id=(int)$_GET['id'];unset($_SESSION['cart'][$id]);header('Location: cart.php');exit;
