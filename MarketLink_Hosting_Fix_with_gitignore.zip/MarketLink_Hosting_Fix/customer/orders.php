<?php
include 'header.php';

$uid = $_SESSION['user_id'];

$orders = mysqli_query($conn, "SELECT o.id, o.total_amount, o.status, o.created_at, u.name AS farmer_name FROM orders o LEFT JOIN users u ON o.farmer_id = u.id WHERE o.customer_id = $uid ORDER BY o.id DESC");
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="section-title mb-1">My Orders</h2>
            <p class="small-muted mb-0">View your order details, products, total amount and current status.</p>
        </div>
    </div>

    <div class="card order-table-card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table order-table mb-0">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Products</th>
                            <th>Farmer</th>
                            <th>Order Date</th>
                            <th>Total</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (mysqli_num_rows($orders) > 0) {
                            while ($order = mysqli_fetch_assoc($orders)) {
                                $orderId = (int)$order['id'];
                                $items = mysqli_query($conn, "SELECT oi.quantity, oi.price, p.name FROM order_items oi LEFT JOIN products p ON oi.product_id = p.id WHERE oi.order_id = $orderId");
                        ?>
                            <tr>
                                <td>
                                    <strong class="order-id">#<?= $orderId ?></strong>
                                </td>

                                <td class="order-products-cell">
                                    <?php
                                    if (mysqli_num_rows($items) > 0) {
                                        while ($item = mysqli_fetch_assoc($items)) {
                                    ?>
                                            <div class="order-product-row">
                                                <div>
                                                    <strong><?= e($item['name']) ?></strong>
                                                    <small>Quantity: <?= (int)$item['quantity'] ?></small>
                                                </div>
                                                <span>Rs. <?= number_format($item['price'], 2) ?></span>
                                            </div>
                                    <?php
                                        }
                                    } else {
                                    ?>
                                        <span class="small-muted">No product details found</span>
                                    <?php
                                    }
                                    ?>
                                </td>

                                <td>
                                    <strong><?= e($order['farmer_name']) ?></strong>
                                </td>

                                <td>
                                    <?= e(date('d M Y', strtotime($order['created_at']))) ?><br>
                                    <small class="small-muted"><?= e(date('h:i A', strtotime($order['created_at']))) ?></small>
                                </td>

                                <td>
                                    <strong class="order-total">Rs. <?= number_format($order['total_amount'], 2) ?></strong>
                                </td>

                                <td>
                                    <?php if ($order['status'] === 'placed') { ?>
                                        <span class="status-pill status-pending">Placed</span>
                                    <?php } elseif ($order['status'] === 'accepted') { ?>
                                        <span class="status-pill status-active">Accepted</span>
                                    <?php } elseif ($order['status'] === 'ready') { ?>
                                        <span class="status-pill status-ready">Ready</span>
                                    <?php } elseif ($order['status'] === 'completed') { ?>
                                        <span class="status-pill status-completed">Completed</span>
                                    <?php } else { ?>
                                        <span class="status-pill status-inactive">Cancelled</span>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php
                            }
                        } else {
                        ?>
                            <tr>
                                <td colspan="6" class="text-center order-empty">
                                    <i class="fa-solid fa-box-open"></i>
                                    <h5>No Orders Yet</h5>
                                    <p>You have not placed any order yet.</p>
                                    <a href="../products.php" class="btn btn-burgundy">Browse Products</a>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
