<?php
require '../config.php'; require '../functions.php'; require_role('customer');
$cart=$_SESSION['cart']??[];
if(!$cart){header('Location: cart.php');exit;}
$name=mysqli_real_escape_string($conn,$_POST['customer_name']??'');
$phone=mysqli_real_escape_string($conn,$_POST['customer_phone']??'');
$address=mysqli_real_escape_string($conn,$_POST['customer_address']??'');
if($name===''||$phone===''||$address===''){$_SESSION['order_error']='Please enter your name, phone number and address before placing an order.';header('Location: cart.php');exit;}
if(!preg_match("/^[A-Za-z .'-]{2,60}$/",$name)){$_SESSION['order_error']='Please enter a valid customer name.';header('Location: cart.php');exit;}
if(!preg_match('/^03[0-9]{9}$/',$phone)){$_SESSION['order_error']='Please enter a valid 11-digit Pakistani mobile number starting with 03.';header('Location: cart.php');exit;}
if(strlen($address)<5){$_SESSION['order_error']='Please enter a complete delivery / pickup address.';header('Location: cart.php');exit;}
$uid=(int)$_SESSION['user_id'];
mysqli_query($conn,"UPDATE users SET name='$name',phone='$phone',address='$address' WHERE id=$uid");
$firstFarmer=0;$total=0;$validItems=[];
foreach($cart as $id=>$qty){$id=(int)$id;$qty=(int)$qty;$q=mysqli_query($conn,"SELECT * FROM products WHERE id=$id AND status='available'");if(mysqli_num_rows($q)>0){$p=mysqli_fetch_assoc($q);if($qty>0&&$qty<=$p['stock_quantity']){$validItems[]=['id'=>$id,'qty'=>$qty,'price'=>$p['price'],'farmer_id'=>$p['farmer_id']];if($firstFarmer===0)$firstFarmer=(int)$p['farmer_id'];$total+=$p['price']*$qty;}}}
if($firstFarmer>0 && $total>0){$legacyCheck=mysqli_query($conn,"SHOW COLUMNS FROM orders LIKE 'pickup_date'");if($legacyCheck && mysqli_num_rows($legacyCheck)>0){mysqli_query($conn,"INSERT INTO orders(customer_id,farmer_id,pickup_date,pickup_time,total_amount,status) VALUES($uid,$firstFarmer,CURDATE(),DATE_FORMAT(NOW(), '%h:%i %p'),$total,'placed')");}else{mysqli_query($conn,"INSERT INTO orders(customer_id,farmer_id,total_amount,status) VALUES($uid,$firstFarmer,$total,'placed')");}$order=mysqli_insert_id($conn);foreach($validItems as $item){mysqli_query($conn,"INSERT INTO order_items(order_id,product_id,quantity,price) VALUES($order,{$item['id']},{$item['qty']},{$item['price']})");mysqli_query($conn,"UPDATE products SET stock_quantity=stock_quantity-{$item['qty']} WHERE id={$item['id']} AND stock_quantity>={$item['qty']}");}$_SESSION['cart']=[];}
header('Location: orders.php');exit;
