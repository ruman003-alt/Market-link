</main>
<script src="../assets/animations.js"></script><script src="../assets/session-protection.js"></script><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script><link rel="stylesheet" href="../assets/ai-chatbot.css"><script src="../assets/ai-chatbot.js" data-api="../api/openrouter.php"></script></body></html>
