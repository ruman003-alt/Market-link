<?php
$page_title='Markets';
include 'header.php';
$rows=mysqli_query($conn,"SELECT * FROM markets ORDER BY id DESC");
$market_data=[];
while($m=mysqli_fetch_assoc($rows)){
    $market_data[]=$m;
}
?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<div class="container py-5">
    <div class="mb-4">
        <span class="eyebrow">Find your pickup point</span>
        <h2 class="section-title mb-1">Local Markets</h2>
        <p class="small-muted mb-0">View market addresses, timings and exact locations on the map.</p>
    </div>

    <div class="market-map-wrap mb-4">
        <div id="marketMap" class="market-map"></div>
    </div>

    <div class="row g-4">
        <?php foreach($market_data as $m): ?>
            <div class="col-md-6">
                <div class="market-card p-4 h-100">
                    <div class="d-flex justify-content-between align-items-start gap-3 mb-2">
                        <h4 class="mb-0"><?=e($m['name'])?></h4>
                        <span class="badge badge-burgundy"><i class="fa-solid fa-location-dot me-1"></i>Map</span>
                    </div>
                    <p class="market-location mb-3"><?=e($m['address'])?></p>
                    <div class="market-meta mb-3">
                        <strong>Days:</strong> <?=e($m['operating_days'])?><br>
                        <strong>Timings:</strong> <?=e($m['timings'])?>
                    </div>
                    <?php if($m['latitude'] !== null && $m['longitude'] !== null): ?>
                        <button type="button" class="btn btn-burgundy" onclick="focusMarket(<?=e($m['latitude'])?>,<?=e($m['longitude'])?>)">
                            <i class="fa-solid fa-location-crosshairs me-1"></i>Show Location
                        </button>
                        <a target="_blank" class="btn btn-outline-dark ms-1" href="https://www.openstreetmap.org/?mlat=<?=e($m['latitude'])?>&mlon=<?=e($m['longitude'])?>#map=16/<?=e($m['latitude'])?>/<?=e($m['longitude'])?>">
                            Open Map
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
var marketLocations = <?=json_encode($market_data, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP)?>;
var marketMap = L.map('marketMap').setView([24.8607, 67.0011], 12);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(marketMap);

var markerGroup = [];
marketLocations.forEach(function(market) {
    if (market.latitude !== null && market.longitude !== null) {
        var marker = L.marker([parseFloat(market.latitude), parseFloat(market.longitude)])
            .addTo(marketMap)
            .bindPopup('<strong>' + escapeMapText(market.name) + '</strong><br>' + escapeMapText(market.address) + '<br><small>' + escapeMapText(market.timings || '') + '</small>');
        markerGroup.push(marker);
    }
});

if (markerGroup.length > 0) {
    var bounds = L.latLngBounds(markerGroup.map(function(marker){ return marker.getLatLng(); }));
    marketMap.fitBounds(bounds, {padding:[35,35]});
}

function focusMarket(lat,lng){
    marketMap.setView([parseFloat(lat),parseFloat(lng)], 16);
    markerGroup.forEach(function(marker){
        var point=marker.getLatLng();
        if(Math.abs(point.lat-parseFloat(lat)) < 0.00001 && Math.abs(point.lng-parseFloat(lng)) < 0.00001){
            marker.openPopup();
        }
    });
}

function escapeMapText(value){
    return String(value || '').replace(/[&<>"']/g,function(character){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[character];
    });
}
</script>
<?php include 'footer.php'; ?>
