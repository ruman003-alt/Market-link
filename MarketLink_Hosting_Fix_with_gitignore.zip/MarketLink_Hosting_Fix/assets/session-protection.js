window.addEventListener('pageshow', function (event) {
    if (event.persisted) {
        window.location.reload();
    }
});

window.addEventListener('pagehide', function () {
    if (document.body) {
        document.body.setAttribute('data-page-hidden', '1');
    }
});
