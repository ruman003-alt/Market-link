document.addEventListener('DOMContentLoaded', function () {
  var selectors = [
    'main section',
    'main .card',
    'main .dashboard-card',
    'main .dash-stat',
    'main .quick-action',
    'main .info-card',
    'main .mini-feature',
    'main .article-card',
    'main .product-catalog-card',
    'main .hero-image-card',
    'main .table-card',
    'main .description-panel',
    'main .detail-meta > div',
    'main .order-total-box',
    'main form'
  ];

  var nodes = document.querySelectorAll(selectors.join(','));
  nodes.forEach(function (el, index) {
    el.classList.add('motion-reveal');
    el.style.setProperty('--motion-delay', Math.min((index % 8) * 55, 385) + 'ms');
  });

  var images = document.querySelectorAll('main img:not(.nav-logo):not(.logo-mark):not(.profile-avatar)');
  images.forEach(function (img) {
    img.classList.add('zoom-media');
    img.addEventListener('error', function () {
      img.classList.add('zoom-media-error');
    }, { once: true });
  });

  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -35px 0px' });

  document.querySelectorAll('.motion-reveal').forEach(function (el) {
    observer.observe(el);
  });

  document.querySelectorAll('.btn, .sidebar-link, .nav-link, .quick-action, .product-thumb').forEach(function (el) {
    el.classList.add('motion-control');
  });
});
