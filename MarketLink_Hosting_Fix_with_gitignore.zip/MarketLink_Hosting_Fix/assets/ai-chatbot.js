
(function(){
  const script=document.currentScript;
  const endpoint=script && script.dataset.api ? script.dataset.api : 'api/openrouter.php';
  const root=document.createElement('div');
  root.className='marketlink-ai';
  root.innerHTML=`
    <button class="marketlink-ai-toggle" type="button" aria-label="Open AI Assistant"><i class="fa-solid fa-robot"></i></button>
    <section class="marketlink-ai-panel" aria-label="MarketLink AI Assistant">
      <div class="marketlink-ai-head">
        <div><strong>MarketLink AI</strong><small>Ask about the marketplace</small></div>
        <button class="marketlink-ai-close" type="button" aria-label="Close"><i class="fa-solid fa-xmark"></i></button>
      </div>
      <div class="marketlink-ai-messages"></div>
      <div class="marketlink-ai-status"></div>
      <form class="marketlink-ai-form">
        <input type="text" maxlength="1000" autocomplete="off" placeholder="Ask something...">
        <button class="marketlink-ai-send" type="submit" aria-label="Send"><i class="fa-solid fa-paper-plane"></i></button>
      </form>
    </section>`;
  document.body.appendChild(root);

  const panel=root.querySelector('.marketlink-ai-panel');
  const toggle=root.querySelector('.marketlink-ai-toggle');
  const close=root.querySelector('.marketlink-ai-close');
  const messagesBox=root.querySelector('.marketlink-ai-messages');
  const status=root.querySelector('.marketlink-ai-status');
  const form=root.querySelector('.marketlink-ai-form');
  const input=form.querySelector('input');
  let messages=[];

  function addMessage(role,text){
    const div=document.createElement('div');
    div.className='marketlink-ai-msg '+(role==='user'?'user':'bot');
    div.textContent=text;
    messagesBox.appendChild(div);
    messagesBox.scrollTop=messagesBox.scrollHeight;
  }
  addMessage('assistant','Hi! I am MarketLink AI. How can I help you?');

  toggle.addEventListener('click',()=>{panel.classList.toggle('open'); if(panel.classList.contains('open')) input.focus();});
  close.addEventListener('click',()=>panel.classList.remove('open'));

  form.addEventListener('submit',async function(e){
    e.preventDefault();
    const text=input.value.trim();
    if(!text) return;
    input.value='';
    addMessage('user',text);
    messages.push({role:'user',content:text});
    status.textContent='AI is typing...';
    input.disabled=true;

    try{
      const res=await fetch(endpoint,{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({messages:messages.slice(-20)})
      });
      const data=await res.json();
      if(!res.ok) throw new Error(data.error || 'Request failed');
      const reply=(data.reply||'').trim() || 'I could not generate a response.';
      addMessage('assistant',reply);
      messages.push({role:'assistant',content:reply});
      status.textContent='';
    }catch(err){
      addMessage('assistant','Sorry, AI could not respond right now. Please check your OpenRouter API key and server connection.');
      status.textContent=err.message || 'Connection error';
    }finally{
      input.disabled=false;
      input.focus();
    }
  });
})();
