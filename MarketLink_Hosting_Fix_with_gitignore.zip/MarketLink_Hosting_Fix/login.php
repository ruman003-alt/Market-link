<?php
$page_title='Login';
include 'header.php';
$error='';
$product_id=(int)($_GET['product_id'] ?? 0);

if($product_id > 0){
    $_SESSION['login_redirect']='product';
    $_SESSION['login_product_id']=$product_id;
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    $email=mysqli_real_escape_string($conn,$_POST['email']);
    $password=$_POST['password'];
    $q=mysqli_query($conn,"SELECT * FROM users WHERE email='$email' AND status='active' LIMIT 1");

    if(mysqli_num_rows($q)>0){
        $u=mysqli_fetch_assoc($q);

        if(password_verify($password,$u['password'])){
            session_regenerate_id(true);
            $_SESSION['user_id']=$u['id'];
            $_SESSION['name']=$u['name'];
            $_SESSION['role']=$u['role'];

            if($_SESSION['role']==='customer' && !empty($_SESSION['pending_cart_product_id'])){
                $pid=(int)$_SESSION['pending_cart_product_id'];
                $pending_qty=(int)($_SESSION['pending_cart_quantity'] ?? 1);

                $product_check=mysqli_query($conn,"SELECT stock_quantity FROM products WHERE id=$pid AND status='available' LIMIT 1");
                if(mysqli_num_rows($product_check)>0){
                    $product_row=mysqli_fetch_assoc($product_check);
                    if($pending_qty > (int)$product_row['stock_quantity']){
                        $pending_qty=(int)$product_row['stock_quantity'];
                    }
                    if($pending_qty > 0){
                        if(!isset($_SESSION['cart'])){$_SESSION['cart']=[];}
                        if(isset($_SESSION['cart'][$pid])){
                            $_SESSION['cart'][$pid]=$_SESSION['cart'][$pid]+$pending_qty;
                        }else{
                            $_SESSION['cart'][$pid]=$pending_qty;
                        }
                    }
                }

                unset($_SESSION['pending_cart_product_id'],$_SESSION['pending_cart_quantity']);

                if(!empty($_SESSION['login_product_id'])){
                    $pid=(int)$_SESSION['login_product_id'];
                    unset($_SESSION['login_redirect'],$_SESSION['login_product_id']);
                    header('Location: product.php?id='.$pid.'&added=1');
                    exit;
                }
            }

            if(isset($_SESSION['login_redirect']) && $_SESSION['login_redirect']==='product' && !empty($_SESSION['login_product_id'])){
                $pid=(int)$_SESSION['login_product_id'];
                unset($_SESSION['login_redirect'],$_SESSION['login_product_id']);
                header('Location: product.php?id='.$pid);
                exit;
            }

            redirect_role();
        }else{
            $error='Invalid email or password.';
        }
    }else{
        $error='Invalid email or password.';
    }
}
?>

<div class="auth-wrap auth-page">
  <div class="container">
    <div class="auth-layout">
      <div class="auth-info">
        <img src="assets/marketlink-brand.png" alt="MarketLink" class="auth-logo">
        <span class="auth-kicker">WELCOME TO MARKETLINK</span>
        <h1>Fresh products.<br>Local connections.</h1>
        <p>Sign in to your MarketLink account to explore local products, check availability, place pickup orders and stay connected with your community market.</p>
        <div class="auth-points">
          <div><i class="fa-solid fa-basket-shopping"></i><span>Explore fresh local products</span></div>
          <div><i class="fa-solid fa-location-dot"></i><span>Find convenient pickup markets</span></div>
          <div><i class="fa-solid fa-receipt"></i><span>Manage your orders easily</span></div>
        </div>
      </div>

      <div class="auth-card card p-4 p-md-5">
        <div class="auth-form-head">
          <span class="auth-form-icon"><i class="fa-solid fa-right-to-bracket"></i></span>
          <div>
            <h3>Welcome Back</h3>
            <p>Login to continue to MarketLink.</p>
          </div>
        </div>

        <?php if($error): ?><div class="alert alert-danger"><?=e($error)?></div><?php endif; ?>
        <?php if($product_id > 0): ?><div class="login-cart-box mb-4"><i class="fa-solid fa-cart-shopping"></i><div><strong>Login to add this product to your cart</strong><span>You can return to the product immediately after login.</span></div></div><?php endif; ?>

        <form method="post">
          <label class="auth-label">Email Address</label>
          <div class="auth-input-wrap"><i class="fa-regular fa-envelope"></i><input class="form-control" name="email" type="email" placeholder="Enter your email" required></div>
          <label class="auth-label">Password</label>
          <div class="auth-input-wrap"><i class="fa-solid fa-lock"></i><input class="form-control" name="password" type="password" placeholder="Enter your password" required></div>
          <button class="btn btn-burgundy w-100 auth-submit"><i class="fa-solid fa-arrow-right-to-bracket me-2"></i>Login</button>
        </form>

        <p class="auth-switch">New to MarketLink? <a href="register.php">Create your account</a></p>
      </div>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>