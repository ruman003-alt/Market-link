<?php
require_once __DIR__.'/config.php';
require_once __DIR__.'/functions.php';
$current_page = basename($_SERVER['PHP_SELF']);
$cart_count = 0;

if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $quantity) {
        $cart_count = $cart_count + (int)$quantity;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($page_title ?? 'MarketLink') ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg main-navbar">
  <div class="container nav-container">
    <a class="navbar-brand brand d-flex align-items-center nav-brand" href="index.php">
      <img src="assets/marketlink-brand.png" alt="MarketLink" class="nav-logo">
    </a>
    <button class="navbar-toggler nav-toggle" type="button" data-bs-toggle="collapse" data-bs-target="#nav" aria-controls="nav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div id="nav" class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1 nav-menu">
        <li class="nav-item"><a class="nav-link <?= $current_page==='index.php'?'active':'' ?>" href="index.php"><i class="fa-solid fa-house"></i><span>Home</span></a></li>
        <li class="nav-item"><a class="nav-link <?= $current_page==='products.php'?'active':'' ?>" href="products.php"><i class="fa-solid fa-basket-shopping"></i><span>Products</span></a></li>
        <li class="nav-item"><a class="nav-link <?= $current_page==='markets.php'?'active':'' ?>" href="markets.php"><i class="fa-solid fa-location-dot"></i><span>Markets</span></a></li>
        <?php if (isset($_SESSION['user_id'])): ?>
          <?php if ($_SESSION['role']==='admin'): ?>
            <li class="nav-item"><a class="nav-link nav-panel-link" href="admin/index.php"><i class="fa-solid fa-gauge-high"></i><span>Admin Panel</span></a></li>
          <?php elseif ($_SESSION['role']==='farmer'): ?>
            <li class="nav-item"><a class="nav-link nav-panel-link" href="farmer/index.php"><i class="fa-solid fa-tractor"></i><span>Farmer Panel</span></a></li>
          <?php else: ?>
            <li class="nav-item"><a class="nav-link" href="customer/orders.php"><i class="fa-solid fa-receipt"></i><span>My Orders</span></a></li>
            <li class="nav-item"><a class="nav-link nav-cart-link" href="customer/cart.php"><i class="fa-solid fa-cart-shopping"></i><span>Cart</span>
              <?php if ($cart_count > 0): ?>
                <span class="cart-count"><?= $cart_count ?></span>
              <?php endif; ?>
            </a></li>
          <?php endif; ?>
          <li class="nav-item nav-action-item"><a class="btn btn-nav-logout nav-action-btn" href="logout.php"><i class="fa-solid fa-right-from-bracket"></i><span>Logout</span></a></li>
        <?php else: ?>
          <li class="nav-item nav-action-item"><a class="btn btn-nav-login nav-action-btn" href="login.php"><i class="fa-solid fa-right-to-bracket"></i><span>Login</span></a></li>
          <li class="nav-item nav-action-item"><a class="btn btn-nav-register nav-action-btn" href="register.php"><i class="fa-solid fa-user-plus"></i><span>Register</span></a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<main>
