<?php
function e($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function require_login() {
    if (!isset($_SESSION['user_id'])) {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Location: ../login.php');
        exit;
    }
}

function require_role($role) {
    require_login();

    if ($_SESSION['role'] !== $role) {
        if ($_SESSION['role'] === 'admin') {
            header('Location: ../admin/index.php');
        } elseif ($_SESSION['role'] === 'farmer') {
            header('Location: ../farmer/index.php');
        } else {
            header('Location: ../products.php');
        }
        exit;
    }
}

function redirect_role() {
    if (!isset($_SESSION['role'])) {
        header('Location: login.php');
        exit;
    }

    if ($_SESSION['role'] === 'admin') {
        header('Location: admin/index.php');
    } elseif ($_SESSION['role'] === 'farmer') {
        header('Location: farmer/index.php');
    } else {
        header('Location: products.php');
    }
    exit;
}
?>
