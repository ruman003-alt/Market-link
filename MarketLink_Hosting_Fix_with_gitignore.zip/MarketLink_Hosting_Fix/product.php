<?php
require 'config.php'; require 'functions.php';
$id=(int)($_GET['id']??0);
if($id<=0){header('Location: products.php');exit;}
$q=mysqli_query($conn,"SELECT p.*,u.name farmer_name FROM products p JOIN users u ON p.farmer_id=u.id WHERE p.id=$id AND p.status='available' LIMIT 1");
if(mysqli_num_rows($q)===0){header('Location: products.php');exit;}
$p=mysqli_fetch_assoc($q);$page_title=$p['name'];include 'header.php';
$gallery=[];for($gi=1;$gi<=5;$gi++){ $g=$gi===1?$p['image']:($p['image'.$gi]??''); if($g)$gallery[]='uploads/products/'.$g; }
?>
<script>function changeProductImage(src){var box=document.getElementById('mainProductImageBox');box.innerHTML='<img id="mainProductImage" src="'+src+'" class="img-fluid w-100 product-detail-image" alt="Product" onerror="showBlackProductImage(this)">';}function showBlackProductImage(img){img.outerHTML='<div id="mainProductImage" class="product-detail-image black-detail-placeholder">Your product image</div>';}</script>
<div class="container py-5"><?php if(isset($_GET['added']) && $_GET['added']=='1'): ?><div class="alert alert-success shadow-sm border-0"><i class="fa-solid fa-circle-check me-2"></i>Product added to your cart. You can continue shopping or open Cart from the navbar.</div><?php endif; ?><div class="row g-5 align-items-start">
<div class="col-lg-6"><div id="mainProductImageBox" class="product-gallery-main border rounded-4 p-2"><?php if(!empty($gallery)): ?><img id="mainProductImage" src="<?=e($gallery[0])?>" class="img-fluid w-100 product-detail-image" onerror="showBlackProductImage(this)" alt="<?=e($p['name'])?>"><?php else: ?><div id="mainProductImage" class="product-detail-image black-detail-placeholder">Your product image</div><?php endif; ?></div><?php if(count($gallery)>1): ?><div class="product-thumbs mt-3 d-flex gap-2 flex-wrap"><?php foreach($gallery as $gi=>$src): ?><button type="button" class="product-thumb <?= $gi===0?'active':'' ?>" onclick="changeProductImage('<?=e($src)?>');document.querySelectorAll('.product-thumb').forEach(function(x){x.classList.remove('active')});this.classList.add('active')"><img src="<?=e($src)?>" onerror="this.style.display='none'"></button><?php endforeach; ?></div><?php endif; ?><div class="gallery-note mt-3"><i class="fa-regular fa-images me-1"></i> Only the photos uploaded for this product are shown here.</div>
<div class="product-gallery-highlights mt-4">
  <h5><i class="fa-solid fa-circle-check me-2"></i>Product Highlights</h5>
  <div class="row g-2">
    <div class="col-12 col-sm-4">
      <div class="gallery-highlight-item"><i class="fa-solid fa-tractor"></i><div><strong>Farmer Direct</strong><span>Directly listed by the farmer</span></div></div>
    </div>
    <div class="col-12 col-sm-4">
      <div class="gallery-highlight-item"><i class="fa-solid fa-leaf"></i><div><strong>Fresh Product</strong><span>Quality-focused marketplace listing</span></div></div>
    </div>
    <div class="col-12 col-sm-4">
      <div class="gallery-highlight-item"><i class="fa-solid fa-shield-halved"></i><div><strong>Secure Order</strong><span>Customer details confirmed at checkout</span></div></div>
    </div>
  </div>
</div></div>
<div class="col-lg-6"><span class="badge badge-burgundy mb-2"><?=e($p['category'])?></span><h1 class="product-detail-title"><?=e($p['name'])?></h1><p class="lead text-secondary"><?=e($p['short_description'])?></p><div class="product-price">Rs. <?=number_format($p['price'],2)?> <small>/ <?=e($p['unit'])?></small></div><div class="detail-meta"><div><span>Available Stock</span><strong><?=e($p['stock_quantity'])?> <?=e($p['unit'])?></strong></div><div><span>Farmer</span><strong><?=e($p['farmer_name'])?></strong></div></div><div class="description-panel">
<h4>Full Product Description</h4>
<p id="productDescription" class="product-description-clamped"><?=nl2br(e($p['description']))?></p>
<button type="button" id="descriptionToggle" class="btn btn-link p-0 text-decoration-none" style="display:none;" onclick="toggleProductDescription()">View More</button>
</div>
<style>
.product-description-clamped{
    display:-webkit-box;
    -webkit-box-orient:vertical;
    -webkit-line-clamp:3;
    overflow:hidden;
}
.product-description-expanded{
    display:block;
}
</style>
<script>
(function(){
    var desc=document.getElementById('productDescription');
    var btn=document.getElementById('descriptionToggle');
    if(!desc || !btn) return;
    if(desc.scrollHeight > desc.clientHeight + 1){
        btn.style.display='inline-block';
    }
})();
function toggleProductDescription(){
    var desc=document.getElementById('productDescription');
    var btn=document.getElementById('descriptionToggle');
    if(!desc || !btn) return;
    var expanded=desc.classList.toggle('product-description-expanded');
    btn.textContent=expanded ? 'View Less' : 'View More';
}
</script><?php if(isset($_SESSION['user_id']) && ($_SESSION['role'] ?? '') === 'customer'): ?>
<div class="customer-order-notice"><i class="fa-solid fa-user-check"></i><div><strong>You can add this product to your pre-order.</strong><span>Your name, phone number and address are confirmed during checkout.</span></div></div>
<form action="customer/add_to_cart.php" method="post" class="row g-2 mt-3">
<input type="hidden" name="product_id" value="<?=$p['id']?>">
<div class="col-4"><label class="form-label">Quantity</label><input class="form-control" type="number" name="quantity" value="1" min="1" max="<?=$p['stock_quantity']?>"></div>
<div class="col-8 d-flex align-items-end"><button class="btn btn-burgundy w-100"><i class="fa-solid fa-cart-plus me-1"></i>Add to Cart</button></div>
</form>
<a class="btn btn-outline-secondary mt-3" href="customer/favorite.php?id=<?=$p['id']?>"><i class="fa-regular fa-heart me-1"></i>Save Favorite</a>
<?php elseif(isset($_SESSION['user_id'])): ?>
<div class="login-cart-box mt-4"><i class="fa-solid fa-user-lock"></i><div><strong>Customer account required</strong><span>Please use a customer account to add products to your cart.</span></div></div>
<?php else: ?>
<div class="login-cart-box mt-4"><i class="fa-solid fa-cart-shopping"></i><div><strong>Login or register to add this product to your cart</strong><span>You can view the complete product details without logging in. Login or create a customer account when you are ready to add it.</span></div></div>
<div class="row g-2 mt-3">
<div class="col-sm-6"><a class="btn btn-burgundy w-100" href="login.php?product_id=<?=$p['id']?>"><i class="fa-solid fa-right-to-bracket me-1"></i>Login to Add</a></div>
<div class="col-sm-6"><a class="btn btn-outline-dark w-100" href="register.php?product_id=<?=$p['id']?>"><i class="fa-solid fa-user-plus me-1"></i>Register</a></div>
</div>
<?php endif; ?>
</div></div>
<div id="productReviewsSection"><hr class="my-5"><div class="row"><div class="col-lg-8"><h3 class="section-title">Customer Reviews</h3><?php $rv=mysqli_query($conn,"SELECT r.*,u.name customer FROM reviews r JOIN users u ON r.customer_id=u.id WHERE r.product_id={$p['id']} ORDER BY r.id DESC");if(mysqli_num_rows($rv)===0): ?><div class="dashboard-card"><p class="mb-0 text-secondary">No reviews yet. Completed customers can add the first review.</p></div><?php endif; ?><?php while($r=mysqli_fetch_assoc($rv)): ?><div class="review-box mb-3"><strong><?=e($r['customer'])?></strong><span class="review-rating"><?=e($r['rating'])?>/5</span><p><?=e($r['comment'])?></p></div><?php endwhile; ?><?php if(isset($_SESSION['user_id']) && ($_SESSION['role'] ?? '') === 'customer'): ?>
<form method="post" action="customer/reviews.php" class="dashboard-card mt-4"><input type="hidden" name="product_id" value="<?=$p['id']?>"><h5>Leave a Review</h5><div class="row g-2"><div class="col-3"><select class="form-select" name="rating"><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option></select></div><div class="col-9"><input class="form-control" name="comment" placeholder="Write your feedback" required></div></div><button class="btn btn-outline-dark mt-2">Submit Review</button></form>
<?php else: ?>
<div class="dashboard-card mt-4"><p class="mb-0 text-secondary"><i class="fa-solid fa-lock me-1"></i>Login as a customer to leave a review.</p></div>
<?php endif; ?></div></div></div>
<style>
@media (min-width: 992px){
  #productReviewsSection{width:calc(50% - 1.5rem);}
  #productReviewsSection > .row > .col-lg-8{width:100%;}
}
</style>
<script>
(function(){
  function cleanProductDetailSpace(){
    if(window.innerWidth < 992) return;
    var topRow=document.querySelector('.container.py-5 > .row.g-5.align-items-start');
    var leftCol=topRow && topRow.children[0];
    var reviews=document.getElementById('productReviewsSection');
    if(!topRow || !leftCol || !reviews) return;
    var gap=topRow.offsetHeight-leftCol.offsetHeight;
    reviews.style.marginTop=(gap>0 ? (-gap) : 0)+'px';
  }
  window.addEventListener('load',cleanProductDetailSpace);
  window.addEventListener('resize',cleanProductDetailSpace);
})();
</script>
<?php include 'footer.php'; ?>
