CREATE DATABASE IF NOT EXISTS marketlink CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE marketlink;

DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS favorites;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS markets;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 role ENUM('admin','farmer','customer') NOT NULL DEFAULT 'customer',
 phone VARCHAR(30), address TEXT,
 status ENUM('active','inactive','pending') NOT NULL DEFAULT 'active',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE markets (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 address TEXT NOT NULL,
 operating_days VARCHAR(100),
 timings VARCHAR(100),
 latitude DECIMAL(10,8) DEFAULT NULL,
 longitude DECIMAL(11,8) DEFAULT NULL,
 map_provider VARCHAR(30) DEFAULT 'OpenStreetMap',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
 id INT AUTO_INCREMENT PRIMARY KEY,
 farmer_id INT NOT NULL,
 name VARCHAR(120) NOT NULL,
 category VARCHAR(60) NOT NULL,
 short_description VARCHAR(255) NOT NULL,
 description TEXT NOT NULL,
 price DECIMAL(10,2) NOT NULL,
 unit VARCHAR(30) NOT NULL,
 stock_quantity INT NOT NULL DEFAULT 0,
 image VARCHAR(255) DEFAULT NULL,
 image2 VARCHAR(255) DEFAULT NULL,
 image3 VARCHAR(255) DEFAULT NULL,
 image4 VARCHAR(255) DEFAULT NULL,
 image5 VARCHAR(255) DEFAULT NULL,
 status ENUM('available','sold_out','inactive') DEFAULT 'available',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (farmer_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE orders (
 id INT AUTO_INCREMENT PRIMARY KEY,
 customer_id INT NOT NULL,
 farmer_id INT NOT NULL,
 total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
 status ENUM('placed','accepted','ready','completed','cancelled') DEFAULT 'placed',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY (farmer_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE order_items (
 id INT AUTO_INCREMENT PRIMARY KEY,
 order_id INT NOT NULL,
 product_id INT NOT NULL,
 quantity INT NOT NULL,
 price DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
 FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE favorites (
 id INT AUTO_INCREMENT PRIMARY KEY,
 customer_id INT NOT NULL,
 product_id INT NOT NULL,
 UNIQUE KEY unique_favorite(customer_id, product_id),
 FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE reviews (
 id INT AUTO_INCREMENT PRIMARY KEY,
 product_id INT NOT NULL,
 customer_id INT NOT NULL,
 rating INT NOT NULL,
 comment TEXT,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
 FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE
);

INSERT INTO users (name,email,password,role,phone,address,status) VALUES
('MarketLink Admin','admin@marketlink.local','$2y$12$s8OAb3HbTVR3BmSIXMCjhupRgyejnJJzPRCJE1sHDYsmrZlC.pLxm','admin','03000000000','Karachi, Pakistan','active'),
('Green Valley Farmer','farmer@marketlink.local','$2y$12$RYzKX5MB66UuukjWfo.LQ.FUX3SkLwGStNee9CR3o2HkNfVipzkxS','farmer','03111111111','Karachi, Pakistan','active'),
('Demo Customer','customer@marketlink.local','$2y$12$kOGzaBcCq3Go4rTKJShy6eMmfRZAwWzZGn2sBAJsXcN9MTxuFbVta','customer','03222222222','Karachi, Pakistan','active');

INSERT INTO markets (name,address,operating_days,timings,latitude,longitude) VALUES
('Karachi Fresh Farmers Market','Main Market Road, Karachi','Saturday, Sunday','08:00 AM - 06:00 PM',24.8607,67.0011),
('Green Community Market','Community Ground, Karachi','Friday, Saturday','09:00 AM - 05:00 PM',24.8738,67.0300),
('Weekend Local Market','Central Avenue, Karachi','Sunday','08:00 AM - 04:00 PM',24.8842,67.0535);

-- Product gallery settings and cleanup
USE marketlink;
ALTER TABLE products MODIFY image VARCHAR(255) DEFAULT NULL;
UPDATE products SET image=NULL WHERE image='default-product.svg';
UPDATE products SET image2=NULL WHERE image2='default-product.svg';
UPDATE products SET image3=NULL WHERE image3='default-product.svg';
UPDATE products SET image4=NULL WHERE image4='default-product.svg';
UPDATE products SET image5=NULL WHERE image5='default-product.svg';
