-- Run this once on an existing MarketLink database to remove the old pickup date/time fields.
ALTER TABLE orders DROP COLUMN pickup_date, DROP COLUMN pickup_time;
